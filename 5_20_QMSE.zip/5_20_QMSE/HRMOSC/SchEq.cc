#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include "SchRK4.hh"
#include "TGraph.h"
#include "TCanvas.h"
#include "TStyle.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TH1F.h"
#include <algorithm>
#include <list>

void init(){
	gROOT->SetStyle("Plain");
	gStyle->SetTitleX(0.54);
	gStyle->SetTitleY(0.97);
	gStyle->SetLabelFont(132,"xy");
	gStyle->SetTitleFont(132,"xy");
	gStyle->SetTextFont(132);
	gStyle->SetStatFont(132);
	gStyle->SetNdivisions(105,"xy");
	gStyle->SetLabelSize(0.055,"xy");
	gStyle->SetTitleSize(0.055,"xy");
	gStyle->SetPadTopMargin(0.25);
	gStyle->SetPadBottomMargin(0.18);
}

int main(){
	static const int Ndim = 2000;
	const double epsilon = 1.0e-6;
	int Nx = 2000;
	double xmin = -10., xmax = 10.;
	//list<double> energyval;
	double energy=2, de=1;
	int k;
	init();
	for(k=0; k< 40; k++){
		/*if(k=0){energyval.push_back(-1);
	
		}*/
		
		double psi[Nx], psip[Nx];
		
		double matchlogd, matchold, x;
		int   iter, i, imatch;
		double psixmin, psipxmin, psixmax, psipxmax;
		double xx[Ndim], psix[Ndim], ee[Ndim];
		SchRK4 schrk4;

		schrk4.Boundary(xmin,xmax,psixmin,psipxmin,psixmax,psipxmax);
		schrk4.InitVal(xmin, xmax, energy, de);
	

		std::cout.precision(17);
		schrk4.RK(xmin, xmax, psixmin, psipxmin, psixmax, psipxmax, de, Nx);
		
		schrk4.getResult(xx, psix, ee, Ndim);
		
		/*if(std::find(energyval.begin(), energyval.end(), ee[Ndim]) !=energyval.end()){
		}else{
		energyval.push_front(ee[Ndim]);*/
		
		if(k+1==1||k+1==5||k+1==11||k+1==13||k+1==15||k+1==17||k+1==18||k+1==19||k+1==20||k+1==21||k+1==22||k+1==40){
	
			TString filename;
			filename.Form("sch%i.pdf",k+1);
			TCanvas *c1 = new TCanvas(filename.Data(), filename.Data(), 800, 400);
			c1->SetGrid();
			c1->Divide(2,1);
		
			TGraph *gr1 = new TGraph(Ndim, xx, psix);
			TGraph *gr2 = new TGraph(Ndim, xx, ee);
		
			c1->cd(1);
			gr1->SetLineColor(2);
			gr1->SetMarkerColor(2);
			gr1->GetHistogram()->SetTitle("#psi(x)");
			gr1->GetHistogram()->GetXaxis()->SetTitle("x");
			gr1->GetHistogram()->GetYaxis()->SetTitle("#psi(x)");
			gr1->GetYaxis()->SetTitleOffset(1.4);
			gPad->SetLeftMargin(0.15);
			gr1->Draw("AP");
		
			c1->cd(2);
			gr2->SetLineColor(2);
			gr2->SetMarkerColor(2);
			gr2->GetHistogram()->SetTitle("Energy");
			gr2->GetHistogram()->GetXaxis()->SetTitle("x");
			gPad->SetLeftMargin(0.15);		/*SetMargin So E_n is clearly visible*/
			double_t *y=gr2-> GetY();
			gr2->GetHistogram()->GetYaxis()->SetTitle("E_n");
			gr2->Draw("AP");
			
			std::cout<<"=====================================\n";
			std::cout<<"# Estart= "<< energy <<" de= "<< de << "\n";
			std::cout<<"# Nx= " << Nx <<" eps= " << epsilon << "\n";
			std::cout<<"# xmin= "<< xmin << "xmax= "<< xmax << "\n";
			std::cout<<"# psi(xmin)= "<< psixmin <<" psip(xmin)= "<< psipxmin <<"\n";	
			std::cout<<"# psi(xmax)= "<< psixmax <<" psip(xmax)= "<< psipxmax <<"\n";
			std::cout << *y <<std::endl;
			std::cout<<"=====================================\n";
			c1->Print(filename,"pdf");
		//}
		}
		energy*=1.12;de++;
	}
}
