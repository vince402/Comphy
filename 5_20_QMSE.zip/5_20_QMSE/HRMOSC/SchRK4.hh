#ifndef SchRK4_HH__
#define SchRK4_HH__

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <math.h>

class SchRK4
{

	private:
		static const int P=10000;
		double xxs[P], psi[P], psip[P];
		double xmin, xmax, energy, de, Energy;
		int iNt;
		double dx;
	public:
	SchRK4(){}
	~SchRK4(){}
	void InitVal(double _xmin, double _xmax, double _energy, double _de);
	
	void getResult(double* xx, double* psix, double* ee, int Nx);

	double V(const double& x){
		return x*x;
	}

	void Boundary(const double& xmin, const double& xmax,

	double& psixmin, double& psipxmin,

	double& psixmax, double& psipxmax){
		psixmin  =  exp(-0.5*xmin*xmin);
		psipxmin =  -xmin*psixmin;
	psixmax  =  exp(-0.5*xmax*xmax);
	psipxmax = -xmax*psixmax;
	}

	double f1(const double& x, const double& psi, const double& psip){
		return psip;
	}

	double f2(const double& x, const double& psi, const double& psip){
		return (V(x)-energy)*psi;
	}

	void RK(const double& xmin, const double& xmax, const double& psixmin, const double& psipxmin, const double& psixmax, const double& psipxmax, double& de, const int& Nx);

	void RKSTEP(double& t, double& x1, double& x2, const double& dt);
};
#endif
