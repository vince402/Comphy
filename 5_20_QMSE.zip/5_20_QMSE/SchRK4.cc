#include "SchRK4.hh"
#include <cmath>

void SchRK4::InitVal(double _xmin, double _xmax, double _energy, double _de){
	xmin = _xmin; xmax = xmax;
	energy = _energy; de =_de;
}

void SchRK4::getResult(double* xx, double* psix, double* ee, int Nx){
	int iNx = Nx;
	for(int i = 0; i < iNx; i++){
		xx[i] = xxs[i];
		psix[i] = psi[i];
		ee[i] = Energy;
	}
}

void SchRK4::RK(const double& xmin, const double& xmax, const double& psixmin, const double& psipxmin, const double& psixmax, const double& psipxmax, double& de, const int& Nx){
	double xs, psistep, psipstep;
	double xm, psinorm, psipleft, psipright;
	int    i, imatch, NxL, NxR;
	int iNx;
	iNx = Nx;
	double dx = (xmax-xmin)/(Nx-1);
	double matchold = 0.0;
	double matchlogd;
	double epsilon = 1.0e-6;
	std::cout.precision(17);
	for(int iter = 1; iter <=10000; iter++){
		imatch = -1;
		for (i = 0; i < Nx; i++){
		xs = xmin + i * dx;
		if(imatch < 0 && (energy-V(xs)) > 0.0) imatch = i;
	}
	if(imatch < 100 || imatch >= Nx-100) imatch = Nx/5-1;
	xm  = xmin + imatch * dx;
	NxL = imatch + 1;
	NxR = Nx - imatch;
	psi[0]  = psixmin;
	psip[0] = psipxmin;
	psistep = psixmin;
	psipstep = psipxmin;
	for(i = 1; i < NxL; i++){
		xs = xmin + (i-1) * dx;
		xxs[i] = xs;
		RKSTEP(xs, psistep, psipstep, dx);
		psi[i]  = psistep;
		psip[i] = psipstep;
	}
	psinorm = psistep;
	psipleft = psipstep;
	psi[Nx-1] = psixmax;
	psip[Nx-1] = psipxmax;
	psistep   = psixmax;
	psipstep  = psipxmax;
	for(i = 1; i < NxR; i++){
		xs = xmax - (i-1) * dx;
		xxs[Nx-1-i] = xs;
		RKSTEP(xs, psistep, psipstep, -dx);
		psi[Nx-1-i]  = psistep;
		psip[Nx-1-i] = psipstep;
	}
	psinorm  = psistep/psinorm;
	psipright = psipstep;
	for(i = 0; i < NxL-1; i++){
		psi[i] *= psinorm;
		psip[i] *= psinorm;
	}
	psipleft *= psinorm; 
	matchlogd = (psipright-psipleft)/(abs(psipright)+abs(psipleft));
	if(std::abs(matchlogd) <= epsilon || std::abs(de/energy) < 1.0e-12 ) break;
	if(matchlogd * matchold < 0.0 ) de = -0.5*de;
	energy += de;
	Energy = energy;
	matchold = matchlogd;
	}
}

void SchRK4::RKSTEP(double& t, double& x1, double& x2, const double& dt){
	double k11,k12,k13,k14,k21,k22,k23,k24;
	double h,h2,h6;	
	h  =dt; 
	h2 =0.5*h; 
	h6 =h/6.0; 
	k11=f1(t,x1,x2);
	k21=f2(t,x1,x2);
	k12=f1(t+h2,x1+h2*k11,x2+h2*k21);
	k22=f2(t+h2,x1+h2*k11,x2+h2*k21);
	k13=f1(t+h2,x1+h2*k12,x2+h2*k22);
	k23=f2(t+h2,x1+h2*k12,x2+h2*k22);
	k14=f1(t+h ,x1+h *k13,x2+h *k23);
	k24=f2(t+h ,x1+h *k13,x2+h *k23);
	t  =t+h;
	x1 =x1+h6*(k11+2.0*(k12+k13)+k14);
	x2 =x2+h6*(k21+2.0*(k22+k23)+k24);
}
