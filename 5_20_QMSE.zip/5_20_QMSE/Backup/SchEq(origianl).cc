#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include "SchRK4.hh"
#include "TGraph.h"
#include "TCanvas.h"
#include "TStyle.h"
#include "TLatex.h"
#include "TROOT.h"
#include "TH1F.h"

void init(){
	gROOT->SetStyle("Plain");
	gStyle->SetTitleX(0.54);
	gStyle->SetTitleY(0.97);
	gStyle->SetLabelFont(132,"xy");
	gStyle->SetTitleFont(132,"xy");
	gStyle->SetTextFont(132);
	gStyle->SetStatFont(132);
	gStyle->SetNdivisions(105,"xy");
	gStyle->SetLabelSize(0.055,"xy");
	gStyle->SetTitleSize(0.055,"xy");
	gStyle->SetPadTopMargin(0.2);
	gStyle->SetPadBottomMargin(0.18);
}

int main(){
	init();
	int Nx = 2000;
	double xmin = -1., xmax = 1.;
	double psi[Nx], psip[Nx];
	double energy = 11., de = 2.;
	const double epsilon = 1.0e-6;
	double matchlogd, matchold, x;
	int   iter, i, imatch;
	double psixmin, psipxmin, psixmax, psipxmax;

	SchRK4 schrk4;
	schrk4.Boundary(xmin,xmax,psixmin,psipxmin,psixmax,psipxmax);
	schrk4.InitVal(xmin, xmax, energy, de);

	std::cout<<"=====================================\n";
	std::cout<<"# Estart= "<< energy <<" de= "<< de << "\n";
	std::cout<<"# Nx= " << Nx <<" eps= " << epsilon << "\n";
	std::cout<<"# xmin= "<< xmin << "xmax= "<< xmax << "\n";
	std::cout<<"# psi(xmin)= "<< psixmin <<" psip(xmin)= "<< psipxmin <<"\n";
	std::cout<<"# psi(xmax)= "<< psixmax <<" psip(xmax)= "<< psipxmax <<"\n";
	std::cout<<"=====================================\n";

	std::cout.precision(17);
	schrk4.RK(xmin, xmax, psixmin, psipxmin, psixmax, psipxmax, de, Nx);
	static const int Ndim = 2000;
	double xx[Ndim], psix[Ndim], ee[Ndim];

	schrk4.getResult(xx, psix, ee, Ndim);
	TString filename;
	filename.Form("sch.pdf");
	TCanvas *c1 = new TCanvas(filename.Data(), filename.Data(), 800, 400);
	c1->SetGrid();
	c1->Divide(2,1);

	TGraph *gr1 = new TGraph(Ndim, xx, psix);
	TGraph *gr2 = new TGraph(Ndim, xx, ee);

	c1->cd(1);
	gr1->SetLineColor(2);
	gr1->SetMarkerColor(2);
	gr1->GetHistogram()->GetXaxis()->SetTitle("x");
	gr1->GetHistogram()->GetYaxis()->SetTitle("#psi(x)");
	gr1->Draw("AP");

	c1->cd(2);
	gr2->SetLineColor(2);
	gr2->SetMarkerColor(2);
	gr2->GetHistogram()->GetXaxis()->SetTitle("x");
	gPad->SetLeftMargin(0.15);		//SetMargin So E_n is clearly visible
	gr2->GetHistogram()->GetYaxis()->SetTitle("E_n");
	gr2->Draw("AP");
	c1->Print(filename,"pdf");
	return 0;
}
